# Screen Stream Mirroring (64-Bit Edition for OBS Studio & VLC)

Ushbu loyiha Android 10–15+ (`arm64-v8a` 64-bit) smartfonlar ekranini va ichki ovozini (**Internal Audio + Microphone**) **TCP protokoli (`MPEG-TS` H.264 + AAC)** orqali **OBS Studio** va **VLC** dasturlariga kechikishsiz (<80 ms) uzatib beruvchi to'liq Android ilova hisoblanadi.

## Telefonda GitHub orqali 2 daqiqada APK yig'ish:
1. GitHub'da yangi repository oching.
2. `OBS_TCP_Screen_Streamer_64bit_Project.zip` faylning o'zini (ochmasdan!) **Upload files** orqali yuklang.
3. **Actions -> set up a workflow yourself** bo'limiga kirib, `build-apk.yml` kodini joylang va **Commit changes** bosing.
4. **Actions** bo'limida tayyor bo'lgan **OBS-TCP-Screen-Streamer-64bit-APK** faylini yuklab oling!
