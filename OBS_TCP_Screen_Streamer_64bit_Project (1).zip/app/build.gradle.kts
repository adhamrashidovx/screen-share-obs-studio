plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "uz.obsstreamer.tcp"
    compileSdk = 34

    defaultConfig {
        applicationId = "uz.obsstreamer.tcp"
        minSdk = 29 // Android 10+ (Official Internal AudioPlaybackCapture & 64-bit MediaCodec)
        targetSdk = 34
        versionCode = 2
        versionName = "1.1.0-64bit"

        // 64-bit architectures (arm64-v8a for all modern phones, x86_64 for PC emulators)
        ndk {
            abiFilters += listOf("arm64-v8a", "x86_64")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Sign with debug key so the release APK installs immediately on any phone without manual signing
            signingConfig = signingConfigs.getByName("debug")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isDebuggable = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.activity:activity-ktx:1.8.2")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
}
