package uz.obsstreamer.tcp

import android.content.Context
import android.content.SharedPreferences

enum class AudioSourceType(val id: Int, val label: String) {
    MIC_AND_INTERNAL(0, "Microphone + internal"),
    INTERNAL_ONLY(1, "Internal audio only"),
    MIC_ONLY(2, "Microphone only"),
    NONE(3, "No audio (Mute)");

    companion object {
        fun fromId(id: Int): AudioSourceType = entries.find { it.id == id } ?: MIC_AND_INTERNAL
    }
}

class StreamSettings(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("obs_tcp_stream_prefs", Context.MODE_PRIVATE)

    var tcpPort: Int
        get() = prefs.getInt("tcp_port", 5000).coerceIn(1024, 65535)
        set(value) = prefs.edit().putInt("tcp_port", value.coerceIn(1024, 65535)).apply()

    var resolutionHeight: Int
        get() = prefs.getInt("res_height", 720) // 480, 720, 1080
        set(value) = prefs.edit().putInt("res_height", value).apply()

    var maxFps: Int
        get() = prefs.getInt("max_fps", 30).coerceIn(15, 60)
        set(value) = prefs.edit().putInt("max_fps", value.coerceIn(15, 60)).apply()

    var videoBitrateKbps: Int
        get() = prefs.getInt("video_bitrate_kbps", 4096).coerceIn(500, 25000)
        set(value) = prefs.edit().putInt("video_bitrate_kbps", value.coerceIn(500, 25000)).apply()

    var forceLandscape: Boolean
        get() = prefs.getBoolean("force_landscape", false)
        set(value) = prefs.edit().putBoolean("force_landscape", value).apply()

    var autoRotate: Boolean
        get() = prefs.getBoolean("auto_rotate", true)
        set(value) = prefs.edit().putBoolean("auto_rotate", value).apply()

    var backgroundMirroring: Boolean
        get() = prefs.getBoolean("background_mirroring", true)
        set(value) = prefs.edit().putBoolean("background_mirroring", value).apply()

    var usbAdbMode: Boolean
        get() = prefs.getBoolean("usb_adb_mode", false)
        set(value) = prefs.edit().putBoolean("usb_adb_mode", value).apply()

    var audioSource: AudioSourceType
        get() = AudioSourceType.fromId(prefs.getInt("audio_source", AudioSourceType.MIC_AND_INTERNAL.id))
        set(value) = prefs.edit().putInt("audio_source", value.id).apply()

    var audioBitrateKbps: Int
        get() = prefs.getInt("audio_bitrate_kbps", 128).coerceIn(64, 320)
        set(value) = prefs.edit().putInt("audio_bitrate_kbps", value.coerceIn(64, 320)).apply()

    var internalVolumePercent: Int
        get() = prefs.getInt("internal_vol_pct", 100).coerceIn(0, 200)
        set(value) = prefs.edit().putInt("internal_vol_pct", value.coerceIn(0, 200)).apply()

    var micVolumePercent: Int
        get() = prefs.getInt("mic_vol_pct", 100).coerceIn(0, 200)
        set(value) = prefs.edit().putInt("mic_vol_pct", value.coerceIn(0, 200)).apply()
}
