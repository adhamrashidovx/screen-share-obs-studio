package uz.obsstreamer.tcp

import java.io.ByteArrayOutputStream
import kotlin.math.min

/**
 * Pure 64-bit Kotlin MPEG-TS (Transport Stream) Muxer (188-byte packets) for OBS Studio & VLC.
 */
class MpegTsMuxer {

    companion object {
        const val TS_PACKET_SIZE = 188
        const val SYNC_BYTE: Byte = 0x47

        const val PID_PAT = 0x0000
        const val PID_PMT = 0x1000
        const val PID_VIDEO = 0x0100
        const val PID_AUDIO = 0x0101

        const val STREAM_TYPE_H264 = 0x1B
        const val STREAM_TYPE_AAC = 0x0F

        const val STREAM_ID_VIDEO = 0xE0
        const val STREAM_ID_AUDIO = 0xC0

        private val CRC32_TABLE = IntArray(256).apply {
            for (i in 0 until 256) {
                var crc = i shl 24
                for (j in 0 until 8) {
                    crc = if ((crc and -0x80000000) != 0) {
                        (crc shl 1) xor 0x04C11DB7
                    } else {
                        crc shl 1
                    }
                }
                this[i] = crc
            }
        }

        fun crc32Mpeg2(data: ByteArray, offset: Int = 0, length: Int = data.size): Int {
            var crc = -0x1 // 0xFFFFFFFF
            for (i in offset until offset + length) {
                val idx = ((crc ushr 24) xor (data[i].toInt() and 0xFF)) and 0xFF
                crc = (crc shl 8) xor CRC32_TABLE[idx]
            }
            return crc
        }
    }

    private var patCc = 0
    private var pmtCc = 0
    private var videoCc = 0
    private var audioCc = 0

    @Volatile
    private var spsAnnexB: ByteArray? = null

    @Volatile
    private var ppsAnnexB: ByteArray? = null

    private val streamStartTimeUs = System.nanoTime() / 1000L

    @Synchronized
    fun setVideoCsd(csd0: ByteArray?, csd1: ByteArray?) {
        if (csd0 != null) spsAnnexB = ensureAnnexB(csd0)
        if (csd1 != null) ppsAnnexB = ensureAnnexB(csd1)
    }

    @Synchronized
    fun buildPatPmtPackets(includeAudio: Boolean = true): ByteArray {
        val out = ByteArrayOutputStream(TS_PACKET_SIZE * 2)
        out.write(createPatPacket())
        out.write(createPmtPacket(includeAudio))
        return out.toByteArray()
    }

    @Synchronized
    fun muxVideoFrame(
        rawNalData: ByteArray,
        presentationTimeUs: Long,
        isKeyFrame: Boolean,
        includeAudioInPmt: Boolean = true
    ): ByteArray {
        val out = ByteArrayOutputStream(rawNalData.size + 1024)

        if (isKeyFrame) {
            out.write(createPatPacket())
            out.write(createPmtPacket(includeAudioInPmt))
        }

        val pts90k = ((presentationTimeUs - streamStartTimeUs).coerceAtLeast(0L) * 90L) / 1000L

        val esPayload = ByteArrayOutputStream(rawNalData.size + 128)
        // H.264 Access Unit Delimiter (AUD)
        esPayload.write(byteArrayOf(0x00, 0x00, 0x00, 0x01, 0x09, 0xF0.toByte()))
        if (isKeyFrame) {
            spsAnnexB?.let { esPayload.write(it) }
            ppsAnnexB?.let { esPayload.write(it) }
        }
        esPayload.write(ensureAnnexB(rawNalData))

        val pesPacket = buildPesPacket(
            streamId = STREAM_ID_VIDEO,
            pts90k = pts90k,
            payload = esPayload.toByteArray(),
            unboundedVideoLength = true
        )

        packetizePesToTs(
            pid = PID_VIDEO,
            pesData = pesPacket,
            pts90kForPcr = pts90k,
            isRandomAccess = isKeyFrame,
            isVideo = true,
            out = out
        )

        return out.toByteArray()
    }

    @Synchronized
    fun muxAudioFrame(
        rawAacData: ByteArray,
        presentationTimeUs: Long,
        sampleRate: Int = 44100,
        channelCount: Int = 2
    ): ByteArray {
        val out = ByteArrayOutputStream(rawAacData.size + 256)
        val pts90k = ((presentationTimeUs - streamStartTimeUs).coerceAtLeast(0L) * 90L) / 1000L

        val adtsFrame = addAdtsHeader(rawAacData, sampleRate, channelCount)
        val pesPacket = buildPesPacket(
            streamId = STREAM_ID_AUDIO,
            pts90k = pts90k,
            payload = adtsFrame,
            unboundedVideoLength = false
        )

        packetizePesToTs(
            pid = PID_AUDIO,
            pesData = pesPacket,
            pts90kForPcr = null,
            isRandomAccess = true,
            isVideo = false,
            out = out
        )

        return out.toByteArray()
    }

    private fun createPatPacket(): ByteArray {
        val packet = ByteArray(TS_PACKET_SIZE) { 0xFF.toByte() }
        packet[0] = SYNC_BYTE
        packet[1] = (0x40 or ((PID_PAT shr 8) and 0x1F)).toByte()
        packet[2] = (PID_PAT and 0xFF).toByte()
        packet[3] = (0x10 or (patCc and 0x0F)).toByte()
        patCc = (patCc + 1) and 0x0F

        packet[4] = 0x00 // Pointer field

        val section = byteArrayOf(
            0x00,
            0xB0.toByte(), 0x0D,
            0x00, 0x01,
            0xC1.toByte(),
            0x00,
            0x00,
            0x00, 0x01,
            (0xE0 or ((PID_PMT shr 8) and 0x1F)).toByte(),
            (PID_PMT and 0xFF).toByte()
        )
        System.arraycopy(section, 0, packet, 5, section.size)
        val crc = crc32Mpeg2(section)
        val crcOffset = 5 + section.size
        packet[crcOffset] = ((crc ushr 24) and 0xFF).toByte()
        packet[crcOffset + 1] = ((crc ushr 16) and 0xFF).toByte()
        packet[crcOffset + 2] = ((crc ushr 8) and 0xFF).toByte()
        packet[crcOffset + 3] = (crc and 0xFF).toByte()
        return packet
    }

    private fun createPmtPacket(includeAudio: Boolean): ByteArray {
        val packet = ByteArray(TS_PACKET_SIZE) { 0xFF.toByte() }
        packet[0] = SYNC_BYTE
        packet[1] = (0x40 or ((PID_PMT shr 8) and 0x1F)).toByte()
        packet[2] = (PID_PMT and 0xFF).toByte()
        packet[3] = (0x10 or (pmtCc and 0x0F)).toByte()
        pmtCc = (pmtCc + 1) and 0x0F

        packet[4] = 0x00 // Pointer field

        val sectionLen = if (includeAudio) 0x17 else 0x12
        val body = ByteArrayOutputStream()
        body.write(0x02)
        body.write(0xB0 or ((sectionLen shr 8) and 0x0F))
        body.write(sectionLen and 0xFF)
        body.write(0x00)
        body.write(0x01)
        body.write(0xC1)
        body.write(0x00)
        body.write(0x00)
        body.write(0xE0 or ((PID_VIDEO shr 8) and 0x1F))
        body.write(PID_VIDEO and 0xFF)
        body.write(0xF0)
        body.write(0x00)

        // Video Stream Descriptor (H.264)
        body.write(STREAM_TYPE_H264)
        body.write(0xE0 or ((PID_VIDEO shr 8) and 0x1F))
        body.write(PID_VIDEO and 0xFF)
        body.write(0xF0)
        body.write(0x00)

        // Audio Stream Descriptor (AAC ADTS)
        if (includeAudio) {
            body.write(STREAM_TYPE_AAC)
            body.write(0xE0 or ((PID_AUDIO shr 8) and 0x1F))
            body.write(PID_AUDIO and 0xFF)
            body.write(0xF0)
            body.write(0x00)
        }

        val sectionBytes = body.toByteArray()
        System.arraycopy(sectionBytes, 0, packet, 5, sectionBytes.size)
        val crc = crc32Mpeg2(sectionBytes)
        val crcOffset = 5 + sectionBytes.size
        packet[crcOffset] = ((crc ushr 24) and 0xFF).toByte()
        packet[crcOffset + 1] = ((crc ushr 16) and 0xFF).toByte()
        packet[crcOffset + 2] = ((crc ushr 8) and 0xFF).toByte()
        packet[crcOffset + 3] = (crc and 0xFF).toByte()
        return packet
    }

    private fun buildPesPacket(
        streamId: Int,
        pts90k: Long,
        payload: ByteArray,
        unboundedVideoLength: Boolean
    ): ByteArray {
        val pesHeaderLen = 8
        val totalPesLen = if (unboundedVideoLength || (payload.size + pesHeaderLen) > 0xFFFF) {
            0
        } else {
            payload.size + pesHeaderLen
        }

        val out = ByteArrayOutputStream(payload.size + 14)
        out.write(0x00)
        out.write(0x00)
        out.write(0x01)
        out.write(streamId and 0xFF)
        out.write((totalPesLen ushr 8) and 0xFF)
        out.write(totalPesLen and 0xFF)
        out.write(0x84)
        out.write(0x80)
        out.write(0x05)

        val pts = pts90k and 0x1FFFFFFFFL
        out.write((0x20 or (((pts ushr 30) and 0x07).toInt() shl 1) or 0x01))
        out.write(((pts ushr 22) and 0xFF).toInt())
        out.write(((((pts ushr 15) and 0x7F).toInt() shl 1) or 0x01))
        out.write(((pts ushr 7) and 0xFF).toInt())
        out.write((((pts and 0x7F).toInt() shl 1) or 0x01))

        out.write(payload)
        return out.toByteArray()
    }

    private fun packetizePesToTs(
        pid: Int,
        pesData: ByteArray,
        pts90kForPcr: Long?,
        isRandomAccess: Boolean,
        isVideo: Boolean,
        out: ByteArrayOutputStream
    ) {
        var offset = 0
        var isFirstPacket = true

        while (offset < pesData.size) {
            val packet = ByteArray(TS_PACKET_SIZE)
            packet[0] = SYNC_BYTE

            val pusi = if (isFirstPacket) 0x40 else 0x00
            packet[1] = (pusi or ((pid shr 8) and 0x1F)).toByte()
            packet[2] = (pid and 0xFF).toByte()

            val cc = if (isVideo) {
                val c = videoCc
                videoCc = (videoCc + 1) and 0x0F
                c
            } else {
                val c = audioCc
                audioCc = (audioCc + 1) and 0x0F
                c
            }

            val remaining = pesData.size - offset
            val needPcr = isFirstPacket && pts90kForPcr != null

            if (needPcr) {
                val minAdaptTotal = 8
                val maxPayload = TS_PACKET_SIZE - 4 - minAdaptTotal
                val payloadSize = min(remaining, maxPayload)
                val stuffing = maxPayload - payloadSize
                val adaptLen = 7 + stuffing

                packet[3] = (0x30 or (cc and 0x0F)).toByte()
                packet[4] = adaptLen.toByte()
                val randomAccessFlag = if (isRandomAccess) 0x40 else 0x00
                packet[5] = (randomAccessFlag or 0x10).toByte()

                val pcrBase = pts90kForPcr!! and 0x1FFFFFFFFL
                packet[6] = ((pcrBase ushr 25) and 0xFF).toByte()
                packet[7] = ((pcrBase ushr 17) and 0xFF).toByte()
                packet[8] = ((pcrBase ushr 9) and 0xFF).toByte()
                packet[9] = ((pcrBase ushr 1) and 0xFF).toByte()
                packet[10] = ((((pcrBase and 1L).toInt()) shl 7) or 0x7E).toByte()
                packet[11] = 0x00

                for (i in 0 until stuffing) {
                    packet[12 + i] = 0xFF.toByte()
                }
                val payloadStart = 4 + 1 + adaptLen
                System.arraycopy(pesData, offset, packet, payloadStart, payloadSize)
                offset += payloadSize
            } else if (remaining < TS_PACKET_SIZE - 4) {
                val payloadSize = remaining
                val adaptTotal = TS_PACKET_SIZE - 4 - payloadSize
                packet[3] = (0x30 or (cc and 0x0F)).toByte()
                packet[4] = (adaptTotal - 1).toByte()
                if (adaptTotal >= 2) {
                    packet[5] = 0x00
                    for (i in 6 until 4 + adaptTotal) {
                        packet[i] = 0xFF.toByte()
                    }
                }
                System.arraycopy(pesData, offset, packet, 4 + adaptTotal, payloadSize)
                offset += payloadSize
            } else {
                packet[3] = (0x10 or (cc and 0x0F)).toByte()
                System.arraycopy(pesData, offset, packet, 4, 184)
                offset += 184
            }

            isFirstPacket = false
            out.write(packet)
        }
    }

    private fun ensureAnnexB(data: ByteArray): ByteArray {
        if (data.size >= 4 && data[0] == 0.toByte() && data[1] == 0.toByte() &&
            ((data[2] == 0.toByte() && data[3] == 1.toByte()) || data[2] == 1.toByte())
        ) {
            return data
        }
        val out = ByteArray(data.size + 4)
        out[0] = 0x00
        out[1] = 0x00
        out[2] = 0x00
        out[3] = 0x01
        System.arraycopy(data, 0, out, 4, data.size)
        return out
    }

    private fun addAdtsHeader(aacPayload: ByteArray, sampleRate: Int, channels: Int): ByteArray {
        val frameLength = aacPayload.size + 7
        val freqIdx = when (sampleRate) {
            96000 -> 0
            88200 -> 1
            64000 -> 2
            48000 -> 3
            44100 -> 4
            32000 -> 5
            24000 -> 6
            22050 -> 7
            16000 -> 8
            12000 -> 9
            11025 -> 10
            8000 -> 11
            else -> 4
        }
        val profile = 2 // AAC LC
        val out = ByteArray(frameLength)
        out[0] = 0xFF.toByte()
        out[1] = 0xF1.toByte()
        out[2] = (((profile - 1) shl 6) or (freqIdx shl 2) or (channels shr 2)).toByte()
        out[3] = (((channels and 3) shl 6) or (frameLength shr 11)).toByte()
        out[4] = ((frameLength and 0x7FF) shr 3).toByte()
        out[5] = (((frameLength and 7) shl 5) or 0x1F).toByte()
        out[6] = 0xFC.toByte()
        System.arraycopy(aacPayload, 0, out, 7, aacPayload.size)
        return out
    }
}
