package uz.obsstreamer.tcp

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

/**
 * 64-bit Low-Latency Audio Capture, Non-Blocking Real-Time PCM Mixer & Hardware AAC Encoder.
 *
 * Uses `READ_NON_BLOCKING` on the secondary stream when mixing Internal + Microphone so that when no game/media
 * sound is playing on the phone, `AudioPlaybackCapture` never blocks the Microphone stream!
 */
class AudioMixerEncoder(
    private val mediaProjection: MediaProjection,
    private val settings: StreamSettings,
    private val hasMicPermission: Boolean,
    private val onEncodedAacFrame: (ByteArray, Long) -> Unit,
    private val onLog: (String) -> Unit
) {
    companion object {
        const val SAMPLE_RATE = 44100
        const val CHANNEL_COUNT = 2
        const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_STEREO
        const val AUDIO_ENCODING = AudioFormat.ENCODING_PCM_16BIT
        const val SAMPLES_PER_FRAME = 1024
        const val BYTES_PER_FRAME = SAMPLES_PER_FRAME * CHANNEL_COUNT * 2 // 4096 bytes (~23.2ms)
    }

    private val isRunning = AtomicBoolean(false)
    private var micRecord: AudioRecord? = null
    private var internalRecord: AudioRecord? = null
    private var aacCodec: MediaCodec? = null
    private var audioThread: Thread? = null

    @SuppressLint("MissingPermission")
    fun start() {
        val sourceMode = settings.audioSource
        if (sourceMode == AudioSourceType.NONE || !hasMicPermission) {
            onLog("Audio muted or permission not granted; streaming video only.")
            return
        }
        if (isRunning.getAndSet(true)) return

        try {
            val minBufSize = max(
                AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_ENCODING) * 2,
                BYTES_PER_FRAME * 4
            )

            // 1. Initialize Internal Audio Capture (Android 10+ API 29+)
            if (sourceMode == AudioSourceType.MIC_AND_INTERNAL || sourceMode == AudioSourceType.INTERNAL_ONLY) {
                try {
                    val playbackConfig = AudioPlaybackCaptureConfiguration.Builder(mediaProjection)
                        .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                        .addMatchingUsage(AudioAttributes.USAGE_GAME)
                        .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                        .build()

                    val audioFormat = AudioFormat.Builder()
                        .setEncoding(AUDIO_ENCODING)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(CHANNEL_CONFIG)
                        .build()

                    val rec = AudioRecord.Builder()
                        .setAudioFormat(audioFormat)
                        .setBufferSizeInBytes(minBufSize)
                        .setAudioPlaybackCaptureConfig(playbackConfig)
                        .build()

                    if (rec.state == AudioRecord.STATE_INITIALIZED) {
                        rec.startRecording()
                        internalRecord = rec
                        onLog("Internal audio capture active (44.1kHz Stereo).")
                    } else {
                        rec.release()
                        onLog("Warning: Internal audio capture failed to initialize.")
                    }
                } catch (e: Exception) {
                    onLog("Internal audio capture error: ${e.message}")
                }
            }

            // 2. Initialize Microphone Capture
            if (sourceMode == AudioSourceType.MIC_AND_INTERNAL || sourceMode == AudioSourceType.MIC_ONLY) {
                try {
                    val rec = AudioRecord(
                        MediaRecorder.AudioSource.MIC,
                        SAMPLE_RATE,
                        CHANNEL_CONFIG,
                        AUDIO_ENCODING,
                        minBufSize
                    )
                    if (rec.state == AudioRecord.STATE_INITIALIZED) {
                        rec.startRecording()
                        micRecord = rec
                        onLog("Microphone audio capture active.")
                    } else {
                        rec.release()
                        onLog("Warning: Microphone capture failed to initialize.")
                    }
                } catch (e: Exception) {
                    onLog("Microphone capture error: ${e.message}")
                }
            }

            if (internalRecord == null && micRecord == null) {
                onLog("No audio sources active; continuing with video only.")
                isRunning.set(false)
                return
            }

            // 3. Initialize Hardware AAC-LC MediaCodec
            val format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, SAMPLE_RATE, CHANNEL_COUNT).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, settings.audioBitrateKbps * 1000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, BYTES_PER_FRAME * 2)
            }

            val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()
            aacCodec = codec

            audioThread = Thread({ mixAndEncodeLoop() }, "ObsAudioMixerThread").apply {
                priority = Thread.MAX_PRIORITY
                start()
            }
        } catch (e: Exception) {
            onLog("Audio encoder initialization failed: ${e.message}")
            stop()
        }
    }

    private fun mixAndEncodeLoop() {
        val internalBuf = ByteArray(BYTES_PER_FRAME)
        val micBuf = ByteArray(BYTES_PER_FRAME)
        val mixedBuf = ByteArray(BYTES_PER_FRAME)
        val bufferInfo = MediaCodec.BufferInfo()

        while (isRunning.get()) {
            try {
                var hasInternal = false
                var hasMic = false

                val mic = micRecord
                val intl = internalRecord

                if (mic != null && intl != null) {
                    // Read Mic blocking (paces the 23.2ms frame loop) and Internal non-blocking so silence never stalls Mic!
                    val micRead = mic.read(micBuf, 0, BYTES_PER_FRAME, AudioRecord.READ_BLOCKING)
                    if (micRead > 0) {
                        if (micRead < BYTES_PER_FRAME) micBuf.fill(0, micRead, BYTES_PER_FRAME)
                        hasMic = true
                    }
                    val intRead = intl.read(internalBuf, 0, BYTES_PER_FRAME, AudioRecord.READ_NON_BLOCKING)
                    if (intRead > 0) {
                        if (intRead < BYTES_PER_FRAME) internalBuf.fill(0, intRead, BYTES_PER_FRAME)
                        hasInternal = true
                    }
                } else if (mic != null) {
                    val micRead = mic.read(micBuf, 0, BYTES_PER_FRAME, AudioRecord.READ_BLOCKING)
                    if (micRead > 0) {
                        if (micRead < BYTES_PER_FRAME) micBuf.fill(0, micRead, BYTES_PER_FRAME)
                        hasMic = true
                    }
                } else if (intl != null) {
                    val intRead = intl.read(internalBuf, 0, BYTES_PER_FRAME, AudioRecord.READ_NON_BLOCKING)
                    if (intRead > 0) {
                        if (intRead < BYTES_PER_FRAME) internalBuf.fill(0, intRead, BYTES_PER_FRAME)
                        hasInternal = true
                    } else {
                        Thread.sleep(20)
                    }
                }

                val intGain = settings.internalVolumePercent / 100.0f
                val micGain = settings.micVolumePercent / 100.0f

                if (hasInternal && hasMic) {
                    val intShorts = ByteBuffer.wrap(internalBuf).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                    val micShorts = ByteBuffer.wrap(micBuf).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                    val outShorts = ByteBuffer.wrap(mixedBuf).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                    val sampleCount = BYTES_PER_FRAME / 2
                    for (i in 0 until sampleCount) {
                        val sInt = (intShorts.get(i) * intGain).toInt()
                        val sMic = (micShorts.get(i) * micGain).toInt()
                        val sum = (sInt + sMic).coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                        outShorts.put(i, sum.toShort())
                    }
                } else if (hasInternal) {
                    applyGain(internalBuf, mixedBuf, intGain)
                } else if (hasMic) {
                    applyGain(micBuf, mixedBuf, micGain)
                } else {
                    mixedBuf.fill(0)
                }

                val codec = aacCodec ?: break
                val inIdx = codec.dequeueInputBuffer(10_000)
                if (inIdx >= 0) {
                    val inBuf = codec.getInputBuffer(inIdx)
                    inBuf?.clear()
                    inBuf?.put(mixedBuf)
                    val ptsUs = System.nanoTime() / 1000L
                    codec.queueInputBuffer(inIdx, 0, BYTES_PER_FRAME, ptsUs, 0)
                }

                var outIdx = codec.dequeueOutputBuffer(bufferInfo, 0)
                while (outIdx >= 0) {
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && bufferInfo.size > 0) {
                        val outBuf = codec.getOutputBuffer(outIdx)
                        if (outBuf != null) {
                            outBuf.position(bufferInfo.offset)
                            outBuf.limit(bufferInfo.offset + bufferInfo.size)
                            val aacBytes = ByteArray(bufferInfo.size)
                            outBuf.get(aacBytes)
                            onEncodedAacFrame(aacBytes, bufferInfo.presentationTimeUs)
                        }
                    }
                    codec.releaseOutputBuffer(outIdx, false)
                    outIdx = codec.dequeueOutputBuffer(bufferInfo, 0)
                }
            } catch (e: Exception) {
                if (isRunning.get()) {
                    onLog("Audio loop warning: ${e.message}")
                }
            }
        }
    }

    private fun applyGain(src: ByteArray, dst: ByteArray, gain: Float) {
        if (gain == 1.0f) {
            System.arraycopy(src, 0, dst, 0, src.size)
            return
        }
        val inShorts = ByteBuffer.wrap(src).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        val outShorts = ByteBuffer.wrap(dst).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        val count = src.size / 2
        for (i in 0 until count) {
            val scaled = (inShorts.get(i) * gain).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
            outShorts.put(i, scaled.toShort())
        }
    }

    fun stop() {
        if (!isRunning.getAndSet(false)) return
        try {
            audioThread?.join(500)
        } catch (_: Exception) {}
        try {
            internalRecord?.stop()
            internalRecord?.release()
        } catch (_: Exception) {}
        internalRecord = null

        try {
            micRecord?.stop()
            micRecord?.release()
        } catch (_: Exception) {}
        micRecord = null

        try {
            aacCodec?.stop()
            aacCodec?.release()
        } catch (_: Exception) {}
        aacCodec = null
    }
}
